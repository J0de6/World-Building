# Ór’esař Archive

A private, local worldbuilding wiki and atlas. Python 3.9+ only, no installs, no network.

## Run
    python3 server.py            # http://127.0.0.1:8080  (PORT=9000 to change)
Data is in `./data` (`wiki.db` + `media/`). Set `WIKI_DATA` to use another folder. The workspace starts empty except for the base map.

## Using it
- **Articles**: Markdown. Link anywhere (body, summary, infobox fields) with `[[entry-id|shown text]]`. The editor's *Insert link* picker searches entries and lets you choose the displayed text.
- **Search** ignores accents and apostrophes (`oresar` finds `Ór’esař`) across titles, aliases, summaries, fields and text.
- **Relationships**: add on an entry page (partner, family, friend, rival, allegiance; optional dates and event). They show on both pages and can be filtered by type.
- **Dates**: free text, shown exactly as entered (`1203`, `c. 1203`, `1203-04-05`, `1203–1210`); sorting uses the first year.
- **Atlas**: drag to pan, wheel or +/− to zoom. Click a pin to select it; click again to open its article. *Edit pins* lets you drag pins or nudge with arrow keys (Shift = larger), or place a pin for a place without coordinates. Positions are stored as 0–1 fractions of the image.
- **Replace artwork**: choose a file under *Base artwork*, drag pins over the preview, *Save as new version*. Earlier artwork and pin positions are listed with *restore*.
- **Journey board**: create a journey (draft/canon), add character tokens, drag them, *Add waypoint here* (snaps to a place within range, or stays free; add date/note/event). Use the scrubber to see last stops and trails. *Add to canon timeline* creates an event.

## Data format (import/export JSON)
    {"entries":[{"id":"char-issa","type":"character|place|culture|faction|species|language|myth|event",
       "title":"","aliases":[],"summary":"","body":"markdown with [[id|text]]",
       "fields":{"species":"","occupation":"","birthName":"","born":"","apparentAge":"","partner":"[[char-rhea]]"},
       "cover":"media-file","gallery":[{"file":"media-file","caption":""}],"x":0.3,"y":0.32}],
     "relationships":[{"id":"rel-1","a":"char-issa","b":"char-rhea","kind":"partner|family|friend|rival|ally","start":"","end":"","event":"evt-id"}],
     "journeys":[{"id":"jr-1","title":"","status":"draft|canon","tokens":[{"id":"t1","char":"char-issa","x":0.5,"y":0.5,
       "stops":[{"place":"place-id","x":0.3,"y":0.3,"date":"1203","note":"","event":"evt-id"}]}]}]}
- IDs are stable and mandatory for imports (`a-z0-9-_.`). Re-importing an ID updates that record; renaming a title never breaks links. Place `fields.kind` is `country`, `settlement` or `landmark`; `x`,`y` give the pin.
- Media: put image files in `data/media/` and reference the filename in `cover`/`gallery`.

## Import / export (same store as the editor)
    python3 server.py import file.json --dry-run   # reports missing link targets, duplicate ids/titles; saves nothing
    python3 server.py import file.json              # saves only if there are no errors
    python3 server.py export out.json
Sample: `demo/demo.json` (flagged `"demo": true`). Remove it with `python3 server.py purge-demo`. `demo/bad.json` shows the dry run catching a missing link.

## Backup / restore
    python3 server.py backup my-backup.zip   # database + all artwork
    python3 server.py restore my-backup.zip  # stop the server first
Also downloadable at `/api/backup.zip`.

## For Codex
Edit a JSON file and run import with `--dry-run` first, then without. Use stable IDs (`char-…`, `place-…`, `evt-…`). Never delete `data/` without a backup.

## Putting this on GitHub
`.gitignore` excludes `data/` (your database and uploaded artwork) and backup zips, so canon is never committed by accident. Keep the repo **private** if you want to commit your own import JSON files. Back up `data/` with `python3 server.py backup`.
